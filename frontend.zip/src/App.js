import React from "react";
import { Route } from "react-router-dom";
import AuthLayout from "./components/layouts/AuthLayouts";
import HomeLayout from "./components/layouts/HomeLayout";
import "./assets/css/bootstrap.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./assets/css/custom.css";
import "./assets/css/media.css";

function App() {
	return (
		<>
			<Route path='/login' component={AuthLayout} />
			<Route path='/register' component={AuthLayout} />
			<Route path='/forgot-password' component={AuthLayout} />
			<Route path='/home' component={HomeLayout} />
		</>
	);
}

export default App;
